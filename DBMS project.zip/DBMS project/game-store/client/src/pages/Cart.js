import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  Container,
  Typography,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Box,
  Button,
  IconButton,
  CircularProgress,
  Divider,
  TextField,
  Card,
  CardContent,
  Grid
} from '@mui/material';
import {
  Delete as DeleteIcon,
  Add as AddIcon,
  Remove as RemoveIcon,
  ShoppingCart as CartIcon,
  ArrowBack as BackIcon
} from '@mui/icons-material';
import { getCustomerCart, getCustomerById } from '../services/api';

const Cart = () => {
  const { customerId } = useParams();
  const navigate = useNavigate();
  const [cart, setCart] = useState(null);
  const [customer, setCustomer] = useState(null);
  const [cartItems, setCartItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [quantities, setQuantities] = useState({});

  useEffect(() => {
    const fetchCartData = async () => {
      try {
        // Fetch customer data and cart data in parallel
        const [customerData, cartData] = await Promise.all([
          getCustomerById(customerId),
          getCustomerCart(customerId)
        ]);
        
        setCustomer(customerData);
        setCart(cartData.cart);
        setCartItems(cartData.items);
        
        // Initialize quantities state based on cart items
        const initialQuantities = {};
        cartData.items.forEach(item => {
          initialQuantities[item.Game_ID] = item.Quantity;
        });
        setQuantities(initialQuantities);
        
        setLoading(false);
      } catch (error) {
        setError('Failed to load cart data');
        setLoading(false);
        console.error('Error fetching cart data:', error);
      }
    };

    fetchCartData();
  }, [customerId]);

  const handleQuantityChange = (gameId, value) => {
    const newValue = parseInt(value);
    if (!isNaN(newValue) && newValue > 0) {
      setQuantities({
        ...quantities,
        [gameId]: newValue
      });
    }
  };

  const increaseQuantity = (gameId) => {
    setQuantities({
      ...quantities,
      [gameId]: quantities[gameId] + 1
    });
  };

  const decreaseQuantity = (gameId) => {
    if (quantities[gameId] > 1) {
      setQuantities({
        ...quantities,
        [gameId]: quantities[gameId] - 1
      });
    }
  };

  const handleRemoveItem = (gameId) => {
    // In a real app, you would call an API to remove the item
    const updatedItems = cartItems.filter(item => item.Game_ID !== gameId);
    setCartItems(updatedItems);
    
    // Recalculate total
    const newTotal = updatedItems.reduce((sum, item) => {
      return sum + (item.Price * quantities[item.Game_ID]);
    }, 0);
    
    setCart({
      ...cart,
      Total: newTotal
    });
  };

  const calculateTotal = () => {
    return cartItems.reduce((sum, item) => {
      return sum + (item.Price * quantities[item.Game_ID]);
    }, 0);
  };

  const handleCheckout = () => {
    // In a real app, you would call an API to create an order
    console.log('Proceeding to checkout with items:', cartItems);
    // Navigate to checkout page or show confirmation
  };

  const handleGoBack = () => {
    navigate(-1);
  };

  if (loading) {
    return (
      <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
        <Box display="flex" justifyContent="center" alignItems="center" minHeight="50vh">
          <CircularProgress />
        </Box>
      </Container>
    );
  }

  if (error) {
    return (
      <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
        <Button startIcon={<BackIcon />} onClick={handleGoBack} sx={{ mb: 2 }}>
          Back
        </Button>
        <Paper sx={{ p: 3 }}>
          <Typography color="error" variant="h6">{error}</Typography>
          <Typography>Failed to load cart data. Please try again later.</Typography>
        </Paper>
      </Container>
    );
  }

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      <Button startIcon={<BackIcon />} onClick={handleGoBack} sx={{ mb: 2 }}>
        Back
      </Button>
      
      <Typography variant="h4" gutterBottom>
        Shopping Cart
      </Typography>
      
      {customer && (
        <Typography variant="subtitle1" gutterBottom>
          Customer: {customer.Name} ({customer.Billing_Email})
        </Typography>
      )}
      
      {cartItems.length === 0 ? (
        <Paper sx={{ p: 4, textAlign: 'center' }}>
          <CartIcon sx={{ fontSize: 60, color: 'text.secondary', mb: 2 }} />
          <Typography variant="h5" gutterBottom>Your cart is empty</Typography>
          <Typography variant="body1" color="text.secondary" paragraph>
            Looks like you haven't added any games to your cart yet.
          </Typography>
          <Button 
            variant="contained" 
            color="primary"
            onClick={() => navigate('/games')}
          >
            Browse Games
          </Button>
        </Paper>
      ) : (
        <Grid container spacing={3}>
          <Grid item xs={12} md={8}>
            <TableContainer component={Paper}>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell>Game</TableCell>
                    <TableCell align="right">Price</TableCell>
                    <TableCell align="center">Quantity</TableCell>
                    <TableCell align="right">Subtotal</TableCell>
                    <TableCell align="center">Actions</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {cartItems.map((item) => {
                    const quantity = quantities[item.Game_ID] || 1;
                    const subtotal = item.Price * quantity;
                    
                    return (
                      <TableRow key={item.Game_ID}>
                        <TableCell>
                          <Typography variant="subtitle1">{item.Title}</Typography>
                        </TableCell>
                        <TableCell align="right">
                          ${item.Price.toFixed(2)}
                        </TableCell>
                        <TableCell align="center">
                          <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                            <IconButton 
                              size="small" 
                              onClick={() => decreaseQuantity(item.Game_ID)}
                              disabled={quantity <= 1}
                            >
                              <RemoveIcon fontSize="small" />
                            </IconButton>
                            <TextField
                              size="small"
                              value={quantity}
                              onChange={(e) => handleQuantityChange(item.Game_ID, e.target.value)}
                              sx={{ width: '60px', mx: 1 }}
                              inputProps={{ 
                                min: 1, 
                                style: { textAlign: 'center' } 
                              }}
                            />
                            <IconButton 
                              size="small" 
                              onClick={() => increaseQuantity(item.Game_ID)}
                            >
                              <AddIcon fontSize="small" />
                            </IconButton>
                          </Box>
                        </TableCell>
                        <TableCell align="right">
                          ${subtotal.toFixed(2)}
                        </TableCell>
                        <TableCell align="center">
                          <IconButton 
                            color="error" 
                            onClick={() => handleRemoveItem(item.Game_ID)}
                          >
                            <DeleteIcon />
                          </IconButton>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </TableContainer>
          </Grid>
          
          <Grid item xs={12} md={4}>
            <Card>
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  Order Summary
                </Typography>
                <Divider sx={{ mb: 2 }} />
                
                <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                  <Typography variant="body1">Items:</Typography>
                  <Typography variant="body1">{cartItems.length}</Typography>
                </Box>
                
                <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                  <Typography variant="body1">Total Quantity:</Typography>
                  <Typography variant="body1">
                    {Object.values(quantities).reduce((sum, qty) => sum + qty, 0)}
                  </Typography>
                </Box>
                
                <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 2 }}>
                  <Typography variant="h6">Total:</Typography>
                  <Typography variant="h6" color="primary">
                    ${calculateTotal().toFixed(2)}
                  </Typography>
                </Box>
                
                <Button 
                  variant="contained" 
                  fullWidth 
                  color="primary"
                  size="large"
                  onClick={handleCheckout}
                >
                  Proceed to Checkout
                </Button>
              </CardContent>
            </Card>
          </Grid>
        </Grid>
      )}
    </Container>
  );
};

export default Cart; 